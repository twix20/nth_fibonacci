
def hello():
	print('hello')