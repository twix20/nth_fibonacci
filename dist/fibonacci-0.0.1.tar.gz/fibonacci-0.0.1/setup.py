import setuptools

setuptools.setup(
    name="fibonacci",
    version="0.0.1",
    author="Piotr Markiewicz",
    description="Yet another fib Nth nubmer implementation",
    include_package_data=True,
    packages=setuptools.find_packages()
)